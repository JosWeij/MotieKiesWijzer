Om het programma MotieKiesWijzer te gebruiken: Download het bestand 'MotieKiesWijzer.zip' en pak het uit in een geselecteerde map. Vervolgens dubbelklik op het bestand 'MotieKiesWijzer.exe' in de juist geselecteerde map.

Het MotieKiesWijzer (Windows) programma is een kieshulp voor de TweedeKamer-verkiezingen in october 2025.

De hulp is niet gebaseerd op plannen/voornemens/beloften/mooie woorden van de verschillende politieke partijen maar op het daadwerkelijke stemgedrag van partijen in de Tweede Kamer aangaande moties en amendementen van het afgelopen jaar (tot ~20250801 volgens Openkamer.org). Dus wat de partijen ondanks de mooie woorden/voornemens daadwerkelijk in de praktijk doen.

Het geeft dus alleen hulp voor bestaande partijen die nu (~2025/08) in de kamer zitten.

Het programma moet gezien worden als een vingeroefening. Het is niet monkey proof. En ook kunnen geen enkele claims ingediend worden. Het is as-is.

Bediening:

Na het starten van het programma (en het lezen van de inleiding) kan linksonder ingesteld worden welke Kamerstukken getoond moeten worden. NB Gezien het aantal stukken ter overweging om alleen de moties te bekijken/beoordelen. Daarna op start drukken om het programma daadwerkelikk te starten. De Kamerstukken worden achtereenvolgens (van jong naar oud) getoond. Met de checkbox "willekeurige volgorde" worden de Kamerstukken in willekeurige volgorde weergegeven.

Per Kamerstuk kan men 'voor' of 'tegen' stemmen. Ook kan men 'niet stemmen' (=default). In dit laatste geval wordt de stemming niet meegeteld.

Letop De stem wordt (pas) vastgelegd op moment dat men met de knop 'Volgende' naar het volgende kamerstuk gaat. Het is niet mogelijk terug te stappen.

In het programma wordt alleen de titel getoond van het Kamerstuk. Indien meer informatie gewenst is kan door op de knop 'meer informatie' informatie zoals de gehele tekst van een Kamerstuk on-line worden opgehaald en dit wordt getoond in de browser. NB Hier is een internetverbinding voor nodig.

Als alle stukken beoordeeld zijn of men wil er mee stoppen dan kan men de tussen/eindstand zien in het tekstscherm rechtsonder. In het geval men er eerder mee stopt dient men op de knop 'tussen/eindstand' te klikken om het resultaat te zien. De partij(en) met de meeste matches komt het meest overeen met de keuzes van de gebruiker van dit programma.

Als de checkbox 'Spieken' wordt aangevinkt dan wordt informatie gegeven waar zojuist over gestemd is (dus achteraf..).

Opmerkingen:

Het kan zijn dat men na het downloaden/uitpakken van het Windowsprogramma MotieKiesWijzer.exe een waarschuwing van Windows krijgt. Dit kan men negeren door op 'meer informatie' te klikken en vervolgens op 'Toch uitvoeren' te klikken. Eventueel kun je met de CRC informatie in CRC.txt controleren of er iets aan het programma veranderd is. Uiteraard kun je na het downloaden ook een viruschecker op het programma loslaten of het programma uitvoeren in een 'Sandbox' of Virtual machine.

Veel plezier er mee.